
-- Create cleaned orders table
CREATE TABLE orders_clean AS
SELECT
    order_id,
    customer_id,
    product_id,
    quantity,
    total_price,
    DATE_FORMAT(STR_TO_DATE(order_date, '%d-%m-%Y'), '%Y-%m-%d') AS order_date
FROM orders_raw
WHERE total_price >= 0 AND product_id IS NOT NULL;
