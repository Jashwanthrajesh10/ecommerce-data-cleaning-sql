
-- KPI Queries

-- Total Revenue
SELECT SUM(total_price) AS total_revenue FROM ecommerce_full_view;

-- Total Orders
SELECT COUNT(DISTINCT order_id) AS total_orders FROM ecommerce_full_view;

-- Unique Customers
SELECT COUNT(DISTINCT customer_id) AS unique_customers FROM ecommerce_full_view;

-- Average Order Value
SELECT AVG(total_price) AS average_order_value FROM ecommerce_full_view;

-- Top 10 Products by Sales
SELECT product_name, SUM(total_price) AS total_sales
FROM ecommerce_full_view
GROUP BY product_name
ORDER BY total_sales DESC
LIMIT 10;

-- Revenue by Category
SELECT category, SUM(total_price) AS revenue_by_category
FROM ecommerce_full_view
GROUP BY category
ORDER BY revenue_by_category DESC;
