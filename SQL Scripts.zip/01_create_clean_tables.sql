
-- Create cleaned customers table
CREATE TABLE customers_clean AS
SELECT DISTINCT
    customer_id,
    INITCAP(name) AS name,
    email,
    REGEXP_REPLACE(phone, '[^0-9]', '') AS phone,
    DATE_FORMAT(STR_TO_DATE(signup_date, '%m/%d/%Y'), '%Y-%m-%d') AS signup_date
FROM customers_raw
WHERE email IS NOT NULL AND email != '';
