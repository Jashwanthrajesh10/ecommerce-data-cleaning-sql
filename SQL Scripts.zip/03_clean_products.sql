
-- Create cleaned products table
CREATE TABLE products_clean AS
SELECT DISTINCT
    product_id,
    INITCAP(name) AS name,
    INITCAP(category) AS category,
    price
FROM products_raw
WHERE name IS NOT NULL AND category IS NOT NULL AND price > 0;
