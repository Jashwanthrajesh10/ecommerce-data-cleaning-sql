
-- Join cleaned tables into ecommerce_full_view
CREATE VIEW ecommerce_full_view AS
SELECT
    o.order_id,
    o.order_date,
    c.customer_id,
    c.name AS customer_name,
    c.email,
    p.product_id,
    p.name AS product_name,
    p.category,
    o.quantity,
    o.total_price
FROM orders_clean o
JOIN customers_clean c ON o.customer_id = c.customer_id
JOIN products_clean p ON o.product_id = p.product_id;
